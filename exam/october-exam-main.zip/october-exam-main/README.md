# october-exam

## How your website should look like in the end
![Alt text](<html-css/images/design.jpg>)

#
#

## Elements with corresponding styles

![Alt text](<html-css/images/Frame 772.png>)

Style: [height: 75px;]

#
#

![Alt text](<html-css/images/Frame 771.png>)

Style: [height: 75px;]

#
#

![Alt text](<html-css/images/Group 76.png>)

Style: [height: 620px; width: 600px;]

#
#

![Alt text](<html-css/images/Subtract.png>)

Style: [height: 110px; width: 110px;]

#
#

![Alt text](<html-css/images/ri_customer-service-2-fill.png>)

Style: [height: 85px; width: 85px;]
